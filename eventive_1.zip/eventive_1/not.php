
<?php


	$serveraddr = "localhost";
    $username = "root";
	$password="";
                      
    $dbname = "eventive";
	
	
	$service=$_POST['id'];
	$avail="No";
	                
	
    


try {
             $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "UPDATE services SET service_available='$avail' WHERE service_id='$service'";
			  
              $conn->exec($stmt);
			  
			  echo "<script>window.alert('Service Not Allocated Successfully');</script>";
			 
			  
			   echo "<script>window.location.assign('wsr.php');</script>";
			   
			 } catch (PDOException $ex) {
                                echo "<script>showalert('Sign Up Error');</script>";
                            }



?>

