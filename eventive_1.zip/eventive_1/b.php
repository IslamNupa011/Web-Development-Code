<?php
session_start();
if(!isset($_SESSION['email'])){
	echo "<script>window.location.assign('index.php');</script>";
}
else{
  $username="root";
  $password="";
  $serveraddr="localhost";
  $dbname="eventive";
  
  $user_email=$_SESSION['email'];
  $in=$_SESSION['id'];
  $a=implode($in);
  
  $date=$_POST['date'];
  $time=$_POST['time'];
  $address=$_POST['address'];
  
  try{
	  $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
	  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	  $stmt="insert into services values('','NULL','birthday','NULL','$time','$date','NULL','1','$a','$address');";
	  $conn->exec($stmt);
	  echo "<script>window.alert('Form submission successfull!Wait for admin response');</script>";
	  echo "<script>window.location.assign('index_1.php');</script>";
  }
  catch(PDOException $ex){
	  echo "<script>showalert('sign up error!');</script>";
  }
  
}
?>
