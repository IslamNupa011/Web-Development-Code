<?php
		
    session_start();
     if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
   else{
	
				 try{
	                  $conn=new PDO("mysql:host=localhost;dbname=eventive","root","");
                       $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					   
					   $in=$_SESSION['id'];
	                   $a=implode($in);
					   
		                 $stmt2="select *from cart order by cart_id desc limit 1;";
			              $pdostmt=$conn->query($stmt2);
			             $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
						 $ca=$table[0];//cart id
			             $n=implode($ca);//string convert
			              
						 
						 
						 $stmt3="insert into payment values('','$n','Bkash','9000','$a'); ";
						 
						 
			            $conn->exec($stmt3);
						 
                    }
                 catch (PDOException $ex) {
                    echo "<tr><td colspan='5' style='text-align:center'>No Data Exists</td></tr>";
                }
							
   }				
							?>