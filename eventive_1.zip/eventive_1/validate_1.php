<?php
 session_start();
    $email="";
    $pass="";
   if(isset($_POST['email']) && isset($_POST['pass'])){
	   $email = $_POST['email'];
        $pass = $_POST['pass'];
   }	
   if(!empty($email) && (!empty($pass))){
	   try{
	   $conn = new PDO("mysql:host=localhost;dbname=eventive",'root', '');
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			  $stmt="select * from admin_user where admin_email='$email' && admin_password='$pass'";
	           $pdostmt=$conn->query($stmt);
			   $info=$pdostmt->fetchAll(PDO::FETCH_NUM);
			    
			   
			   if($pdostmt->rowCount() == 1){
				     $_SESSION['a_email'] = $email;
					 $_SESSION['a_id']=$info[0];
					
                     echo "<script>window.location.assign('admin_1.php');</script>";
				   
			   }
			   else{
				   echo"<script>window.location.assign('admin.php?status=invalid');</script>";
			   }
	   }
	   catch(PDOException $ex){
		   echo "<script> window.location.assign('admin.php?status=dberror');</script>";
	   }
   }



?>