<?php

session_start();
if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
else{
  $serveraddr = "localhost";
    $username = "root";
      $password="";                
    $dbname = "eventive";
   
   
   $user_email=$_SESSION['email'];
	
	
	
	$in=$_SESSION['id'];
	$a=implode($in);
   
  
   
   $m=$_POST['message'];

  
   
   
   

   try{
	    $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt="insert into msg values('','$user_email','$m','$a');";
		
		
		
		$conn->exec($stmt);
		echo "<script>window.alert('Form Submission Successful,Message sent succcessfully');</script>";
		echo "<script>window.location.assign('index_1.php');</script>";
   }
   catch (PDOException $ex) {
                                echo "<script>showalert('Sign Up Error');</script>";
                            }
   
}
?>