<?php

session_start();
    if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
else{
	
	$in=$_SESSION['id'];
	      $a=implode($in);
		  
		  $input=$_POST['newp'];
    try{
		 $conn = new PDO("mysql:host=localhost;dbname=eventive", "root", "");
         $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		 
		  $in=$_SESSION['id'];
	      $a=implode($in);
		  
		  $input=$_POST['newp'];
		  
		   $stmt="update user_signup set user_password='$input' where user_id='$a'; ";
		$pdostmt= $conn->query($stmt);
		
		echo"<script>window.alert('password changed successfully');</script>";
		echo"<script>window.location.assign('cart.php');</script>";
		
	}
	catch(PDOExeption $ex){
		echo"<script>window.alert('error');</script>";
	}

}


?>