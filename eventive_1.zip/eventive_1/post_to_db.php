<?php

   $servername = "localhost";
    $username = "root";
    $password = "";                    
    $dbname = "eventive";
    
   $user_name=$_POST['uname'];
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$address=$_POST['address'];
	$phone=$_POST['phone'];
	
	try{
			 $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "insert into user_signup values(' ','$user_name','$pass','$phone','$email','$address');";
			 $conn->exec($stmt);
			 echo "<script>window.alert('User Sign Up Is Successfull');</script>";
			 echo "<script>window.location.assign('index.php');</script>";
		
	}catch(PDOException $ex){
		
		echo "<script>showalert('sign up error');</script>";
		
	}



?>